package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * Servlet implementation class SearchServelet
 */
@WebServlet("/SearchServelet")
public class SearchServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		try (PrintWriter out = response.getWriter()) {
			response.setContentType("text/html");
			String detail = request.getParameter("detail");
			SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Session session = sf.openSession();
		session.beginTransaction();
		Query qrs = session.createQuery("from Employee");
		List<Employee> allcon = qrs.getResultList();
		out.println("<html><head><title>View Contacts</title></head><body>");
		out.println("<table width='1024px' border='1px'>");
		out.println("<tr><th>EmployeeId</th><th>Email</th><th>FirstName</th><th>LastName</th><th>LastName</th><th>Location</th><th>Desigination</th><th>Dob</th></tr>");
		
		for(Employee emp : allcon){
			out.println("1");
			out.println(detail.equals(emp.getEmployeeId()));
		if(detail.equals(emp.getEmployeeId())||detail.equals(emp.getEmail())||detail.equals(emp.getFirstName())||detail.equals(emp.getLocation())||detail.equals( emp.getPhone())||detail.equals(emp.getDes())||detail.equals(emp.getDob())){
			out.println("<tr>");
			
			out.println("<td> " + emp.getEmployeeId() + " </td> <td> " + emp.getEmail() + " </td> <td>  " + emp.getFirstName() + " </td> <td>  " + emp.getLastName() + " </td> <td>  " + emp.getLocation() + " </td> <td>  " + emp.getPhone() + "  </td> <td> " + emp.getDes() + "  </td> <td> " + emp.getDob()+ " </td>");
			out.println("'<button><a href=\"\">Edit</a>'");
		}
		}
		out.println("</table>");
		out.println("</body></html>");
		//Employee emp =session.get(Item.class, 1);
		out.println("4");
		session.getTransaction().commit();
		session.close();
		}
		 catch (Exception e1) {
				System.out.println(e1);
			}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
