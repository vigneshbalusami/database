package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * Servlet implementation class EditServelet
 */
@WebServlet("/EditServelet")
public class EditServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try (PrintWriter out = response.getWriter()) {
			response.setContentType("text/html");
			String details = request.getParameter("detail");
			SessionFactory sf = new Configuration().configure().buildSessionFactory();
			Session session = sf.openSession();
			session.beginTransaction();
			Query qrs = session.createQuery("from Employee");
			List<Employee> allcon = qrs.getResultList();
			Employee emp2 = null;
			out.println("1");
			for (Employee emp : allcon) {
				out.println("2");
				if (details.equals(String.valueOf(emp.getEmployeeId()))) {
					emp2 = emp;
					out.println("3");
					break;
				}
			}
			out.println("4");
			out.println("<html><head><title>Edit Contacts</title></head><body>");
			out.println("<form name=\"loginForm\" method=\"Get\" action=\"UpdateServelet\">");
			out.println("<table>");

			out.println("<tr>");
			out.println("<td><lable>EmployeeId :</lable></td>");
			out.println("<td><input type=\"text\" name=\"employeeid\" value = '"+ emp2.getEmployeeId() +"' disabled /></td>");
			out.println("</tr>");
			
			
			out.println("<tr>");
			out.println("<td><lable>Frist Name :</lable></td>");
			out.println("<td><input type=\"text\" name=\"firstname\" value = '"+ emp2.getFirstName() +"' /></td>");
			out.println("</tr>");
			
			out.println("<tr>");
			out.println("<td><lable>Last Name :</lable></td>");
			out.println("<td><input type=\"text\" name=\"lastname\" value = '"+ emp2.getLastName() +"' /></td>");
			out.println("</tr>");

			out.println("<tr>");
			out.println("<td><lable>Email :</lable></td>");
			out.println("<td><input type=\"text\" name=\"email\" value = '"+ emp2.getEmail() +"' /></td>");
			out.println("</tr>");
			

			out.println("<tr>");
			out.println("<td><lable>phone :</lable></td>");
			out.println("<td><input type=\"text\" name=\"phone\" value = '"+ emp2.getPhone() +"' /></td>");
			out.println("</tr>");

			out.println("<tr>");
			out.println("<td><lable>Location :</lable></td>");
			out.println("<td><input type=\"text\" name=\"location\" value = '"+ emp2.getLocation() +"' /></td>");
			out.println("</tr>");

			out.println("<tr>");
			out.println("<td><lable>Desigination :</lable></td>");
			out.println("<td><input type=\"text\" name=\"desigination\" value = '"+ emp2.getDes() +"' /></td>");
			out.println("</tr>");

			out.println("<tr>");
			out.println("<td><lable>Dob :</lable></td>");
			out.println("<td><input type=\"text\" name=\"dob\" value = '"+ emp2.getDob() +"' /></td>");
			out.println("</tr>");
			out.println("<tr><td><input type=\"submit\" value=\"Update\" /></td></tr>");
			
			out.println("</table>");
			out.println("</body></html>");
			// Employee emp =session.get(Item.class, 1);
			session.getTransaction().commit();
			session.close();
		} catch (Exception e1) {
			System.out.println(e1);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
