package com;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Employee")
public class Employee {
	public enum Desigination {
		HR, PROJECT_MANAGER, MEMBER, TEAM_LEAD
	};

	@Id
	@Column
	@GeneratedValue
	private String employeeId;
	@Column(name = "first_name", nullable = false, length = 50)
	private String firstName;
	@Column(name = "last_name", nullable = true, length = 50)
	private String lastName;
	@Column(name = "email_id", nullable = false, length = 25)
	private String email;
	@Column(name = "phone_no", nullable = false, length = 10)
	private long phone;
	@Column(name = "DOB", nullable = false)
	private Date dob;
	@Column(name = "location", nullable = false, length = 50)
	private String location;
	@Enumerated(EnumType.STRING)
	@Column(name = "desigination", nullable = false, length = 16)
	private Desigination des;

	public Employee(String firstName, String lastName, String email, long phone, Date dob, String location,
			Desigination des) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phone = phone;
		this.dob = dob;
		this.location = location;
		this.des = des;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Desigination getDes() {
		return des;
	}

	public void setDes(Desigination des) {
		this.des = des;
	}

}
