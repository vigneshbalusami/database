package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.Employee.Desigination;

/**
 * Servlet implementation class EmployeeSignUp
 */
@WebServlet("/EmployeeSignUp")
public class EmployeeSignUp extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EmployeeSignUp() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		try (PrintWriter out = response.getWriter()) {

			String firstName = request.getParameter("firstname");
			String lastName = request.getParameter("lastname");
			String email = request.getParameter("email");
			long phone = Long.parseLong(request.getParameter("phone"));
			DateFormat format = new SimpleDateFormat("yyyy-mm-dd");
			Date dob = format.parse(request.getParameter("dob"));
			String location = request.getParameter("location");
			Desigination des = Desigination.valueOf(request.getParameter("desigination"));
			out.println(firstName + " " + lastName + " " + email + " " + dob + " " + phone + " " + "* " + location + " "
					+ des);
			SessionFactory sf = new Configuration().configure().buildSessionFactory();
			Session session = sf.openSession();
			session.beginTransaction();

			Employee employee = new Employee(firstName, lastName, email, phone, dob, location, des);
			session.save(employee);
			session.getTransaction().commit();
			session.close();
			out.println("sucess fully insert");
			response.sendRedirect("../../test/index.html");
		} catch (Exception e1) {
			System.out.println(e1);
		}
	}

}
