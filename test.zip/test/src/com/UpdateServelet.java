package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.Employee.Desigination;

/**
 * Servlet implementation class UpdateServelet
 */
@WebServlet("/UpdateServelet")
public class UpdateServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try (PrintWriter out = response.getWriter()) {
			response.setContentType("text/html");
			String empid = String.valueOf(request.getParameter("employeeid"));
			String firstName = request.getParameter("firstname");
			String lastName = request.getParameter("lastname");
			String email = request.getParameter("email");
			long phone = Long.parseLong(request.getParameter("phone"));
			DateFormat format = new SimpleDateFormat("yyyy-mm-dd");
			Date dob = format.parse(request.getParameter("dob"));
			String location = request.getParameter("location");
			Desigination des = Desigination.valueOf(request.getParameter("desigination"));
			SessionFactory sf = new Configuration().configure().buildSessionFactory();
			Session session = sf.openSession();
			session.beginTransaction();

			Query qrs = session.createQuery("from Employee");
			List<Employee> allcon = qrs.getResultList();
			Employee emp2 = null;
			out.println("1");
			for (Employee emp : allcon) {
				out.println("2");
				out.println(empid);
				out.println(emp.getEmployeeId());
				if (empid.equals(String.valueOf(emp.getEmployeeId()))) {
					emp2 = emp;
					out.println("3");
					break;
				}
			}
			emp2.setFirstName(firstName);
			emp2.setLastName(lastName);
			emp2.setPhone(phone);
			emp2.setEmail(email);
			emp2.setLocation(location);
			emp2.setDob(dob);
			emp2.setDes(des);
			session.save(emp2);
			// Employee emp =session.get(Item.class, 1);
			session.getTransaction().commit();
			session.close();
			out.println("sucess fully insert");
			response.sendRedirect("../../test/index.html");
		} catch (Exception e1) {
			System.out.println(e1);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
